This database was used on the Journal Paper "Automatic Identification and Counting of Scenedesmus Polymorphic Microalgae from Microscopic Images" by Jhony-Heriberto Giraldo-Zuluaga, Augusto Salazar, German Diez, Alexander Gomez, Tatiana Mart�nez, J. F. Vargas, Mariana Pe�uela, Universidad de Antioquia, Colombia.

If you found this database useful, please cite the paper "Automatic identification of Scenedesmus polymorphic microalgae from microscopic images":

@Article{Giraldo-Zuluaga2017,

	author="Giraldo-Zuluaga, Jhony-Heriberto
 and Salazar, Augusto 
and Diez, German 
and Gomez, Alexander
 and Mart{\'i}nez, Tatiana
and Vargas, J. F.
 and Pe{\~{n}}uela, Mariana",

	title="Automatic identification of Scenedesmus polymorphic microalgae from microscopic images",

	journal="Pattern Analysis and Applications",

	year="2017",

	month="Oct",

	day="13",

	issn="1433-755X",

	doi="10.1007/s10044-017-0662-3",

	url="https://doi.org/10.1007/s10044-017-0662-3"

}

